﻿//Copyright(c) 2001-2023 Aspose Pty Ltd.All rights reserved.
using System;
using System.IO;
using Aspose.Words.Saving;
using Aspose.BarCode.Utils;

namespace CustomBarcode
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //set license
            SetLicense();

            //create documents with barcodes
            CreateDocumentWithBarcode("DISPLAYBARCODE “Aspose.Barcode” QR", "simpleQR");
            CreateDocumentWithBarcode("DISPLAYBARCODE “Aspose.Barcode” QR \\f  0x00FF00 \\b 0xFF0000", "colorQR");
            CreateDocumentWithBarcode("DISPLAYBARCODE “ASPOSE BARCODE” CODE39 \\t", "displayTextCODE39");
            CreateDocumentWithBarcode("DISPLAYBARCODE “Aspose.Barcode” QR \\q 3", "errorLevel3QR");
            CreateDocumentWithBarcode("DISPLAYBARCODE “Aspose.Barcode” QR \\r 1", "rotatedQR");
            CreateDocumentWithBarcode("DISPLAYBARCODE “Aspose.Barcode” QR \\s 25", "scaledQR");
            CreateDocumentWithBarcode("DISPLAYBARCODE “ASPOSE BARCODE” CODE39 \\h 1200", "heightCODE39");
            CreateDocumentWithBarcode("DISPLAYBARCODE “501234567890” EAN13 \\p STD", "standardEAN13");
            CreateDocumentWithBarcode("DISPLAYBARCODE “50123456789012” EAN13 \\p SUP2", "supplement2EAN13");
            CreateDocumentWithBarcode("DISPLAYBARCODE “50123456789012345” EAN13 \\p SUP5", "supplement5EAN13");
            CreateDocumentWithBarcode("DISPLAYBARCODE “501234567890” EAN13 \\p CASE", "caseEAN13");

            Console.WriteLine("Complete!");
            Console.ReadLine();
        }

        internal static void CreateDocumentWithBarcode(string barcodeField, string documentName)
        {
            //path of Data
            string path = @".\..\..\..\Data\";
            Directory.CreateDirectory(path);
            
            Aspose.Words.Document wordDoc = new Aspose.Words.Document();
            Aspose.Words.DocumentBuilder wordBuilder = new Aspose.Words.DocumentBuilder(wordDoc);
            //set up CustomBarcodeGenerator
            wordDoc.FieldOptions.BarcodeGenerator = new CustomBarcodeGenerator();

            wordBuilder.Write("Header\n");
            wordBuilder.InsertField(barcodeField);
            wordBuilder.Write("\nFooter.");

            wordDoc.Save($"{path}{documentName}.docx", Aspose.Words.SaveFormat.Docx);
            
            PdfSaveOptions pso = new PdfSaveOptions();
            pso.Compliance = PdfCompliance.Pdf17;

            wordDoc.Save($"{path}{documentName}.pdf", pso);
        }

        internal static void SetLicense()
        {
            string licenseName = @".\..\..\..\License\Aspose.Total.Product.Family.lic";
            (new Aspose.BarCode.License()).SetLicense(licenseName);
            (new Aspose.Words.License()).SetLicense(licenseName);
        }
    }
}