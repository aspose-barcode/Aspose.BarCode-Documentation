﻿namespace mauibarcode;

public static class MauiProgram
{
	public static MauiApp CreateMauiApp()
	{
		//set license
		Aspose.Barcode.Utils.LicenseManager.SetLicense();

		var builder = MauiApp.CreateBuilder();
		builder
			.UseMauiApp<App>()
			.ConfigureFonts(fonts =>
			{
				fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular"); fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
				fonts.AddFont("pristina.ttf", "Pristina");
			});

		//register fonts
		Aspose.Drawing.MAUI.PrivateFontsManager.RegisterFontsFromAppPackage("OpenSans-Regular.ttf", "OpenSans-Semibold.ttf", "pristina.ttf");

		return builder.Build();
	}
}
