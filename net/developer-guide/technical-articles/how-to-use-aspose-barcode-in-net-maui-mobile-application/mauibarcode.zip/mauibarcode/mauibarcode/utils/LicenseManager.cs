﻿//Copyright(c) 2001-2023 Aspose Pty Ltd.All rights reserved.

namespace Aspose.Barcode.Utils
{
    /// <summary>
    /// Aspose.Barcode License initializer
    /// </summary>
    public class LicenseManager
    {
        private static LicenseManager _instance = new LicenseManager();
        private LicenseManager()
        {
            // init the license
            (new Aspose.BarCode.License()).SetLicense(StorageUtils.ReadAppPackageFileToMemoryStream("Aspose.License.lic"));
        }
        
        /// <summary>
        /// Set License one time
        /// </summary>
        public static void SetLicense()
        {
            LicenseManager local = _instance;
        }
    }
}
