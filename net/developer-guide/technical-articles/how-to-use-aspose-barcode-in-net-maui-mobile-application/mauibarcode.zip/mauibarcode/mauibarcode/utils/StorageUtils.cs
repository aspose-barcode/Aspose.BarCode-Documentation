﻿//Copyright(c) 2001-2023 Aspose Pty Ltd.All rights reserved.

namespace Aspose.Barcode.Utils
{
    /// <summary>
    /// Storage Utilities
    /// </summary>
    public class StorageUtils
    {
        /// <summary>
        /// Reads data from files in App package into memory stream because on some system 
        /// stream from package does not have lenght and position
        /// </summary>
        ///<param name="fontFiles">filename in App package</param>  
        /// <returns>initilized memory stream</returns> 
        public static MemoryStream ReadAppPackageFileToMemoryStream(string filename)
        {
            if (!Microsoft.Maui.Storage.FileSystem.Current.AppPackageFileExistsAsync(filename).Result) return null;
            
            using (Stream fstream = Microsoft.Maui.Storage.FileSystem.Current.OpenAppPackageFileAsync(filename).Result)
            {
                List<byte> streamData = new List<byte>();
                int realRead = 0;
                byte[] data = new byte[262144];
                do
                {
                    realRead = fstream.Read(data, 0, data.Length);
                    for(int i = 0; i < realRead; ++i)
                        streamData.Add(data[i]);
                } while (0 != realRead);

                return new MemoryStream(streamData.ToArray());
            }
        }
    }
}
