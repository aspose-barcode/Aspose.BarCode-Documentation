﻿//Copyright(c) 2001-2023 Aspose Pty Ltd.All rights reserved.

using System.Text;
using Aspose.Drawing;

namespace Aspose.Barcode.Utils
{
    public class MAUIConsole
    {
        //Text buffer of the console
        private StringBuilder _strText = new StringBuilder();
        //image control where we draw text from buffer
        private Microsoft.Maui.Controls.Image _image;
        //image width
        private int _width;
        //image height
        private int _height;
        //padding around image
        private int _padding;
        //background color
        private Aspose.Drawing.Color _back;
        //text color
        private Aspose.Drawing.Color _fore;
        //size of the drawing font
        private float _fontSize;

        /// <summary>
        /// Constructor of the emulated console
        /// </summary>
        ///<param name="image">Image control</param>  
        ///<param name="width">image width</param>  
        ///<param name="height">image height</param>  
        public MAUIConsole(Microsoft.Maui.Controls.Image image, int width, int height)
            : this (image, width, height, 5, Aspose.Drawing.Color.Aquamarine, Aspose.Drawing.Color.Black, 10)
        {
        }

        /// <summary>
        /// Constructor of the emulated console
        /// </summary>
        ///<param name="image">Image control</param>  
        ///<param name="width">image width</param>  
        ///<param name="height">image height</param>  
        ///<param name="padding">padding around image</param>  
        ///<param name="back">background Color</param>  
        ///<param name="fore">text color</param>  
        ///<param name="fontSize">size of the drawing font</param>  
        public MAUIConsole(Microsoft.Maui.Controls.Image image, int width, int height, int padding, Aspose.Drawing.Color back, Aspose.Drawing.Color fore, float fontSize)
        {
            _image = image;
            _width = width;
            _height = height;
            _padding = padding;
            _back = back;
            _fore = fore;
            _fontSize = fontSize;
        }

        /// <summary>
        /// Draws text on emulated console Microsoft.Maui.Controls.Image
        /// </summary>
        ///<param name="text">text which is added to buffer</param>  
        ///<param name="immediately">do we draw immediately on in Draw method</param>
        public void Write(string text, bool immediately = false)
        {
            _strText.Append(text);
            if (immediately) Draw();
        }

        /// <summary>
        /// Draws text on emulated console Microsoft.Maui.Controls.Image with adding next row
        /// </summary>
        ///<param name="text">text which is added to buffer</param>  
        ///<param name="immediately">do we draw immediately on in Draw method</param>
        public void WriteLine(string text, bool immediately = false)
        {
            _strText.Append(text + "\n");
            if (immediately) Draw();
        }

        /// <summary>
        /// Draws text on emulated console Microsoft.Maui.Controls.Image
        /// </summary>
        public void Draw()
        {
            DrawString(_image, _strText.ToString(), _width, _height, _padding, _back, _fore, _fontSize);
        }

        /// <summary>
        /// Draws text on image to emulate console
        /// </summary>
        ///<param name="image">Image control</param>  
        ///<param name="text">drawn text</param>  
        ///<param name="width">image width</param>  
        ///<param name="height">image height</param>  
        public static void DrawString(Microsoft.Maui.Controls.Image image, string text, int width, int height)
        {
            DrawString(image, text, width, height, 5, Aspose.Drawing.Color.Aquamarine, Aspose.Drawing.Color.Black, 10);
        }

        /// <summary>
        /// Draws text on image to emulate console
        /// </summary>
        ///<param name="image">Image control</param>  
        ///<param name="text">drawn text</param>  
        ///<param name="width">image width</param>  
        ///<param name="height">image height</param>  
        ///<param name="padding">padding around image</param>  
        ///<param name="back">background Color</param>  
        ///<param name="fore">text color</param>  
        ///<param name="fontSize">size of the drawing font</param>  
        public static void DrawString(Microsoft.Maui.Controls.Image image, string text, int width, int height, int padding, Aspose.Drawing.Color back, Aspose.Drawing.Color fore, float fontSize)
        {
            using (Bitmap bmp = new Bitmap(width, height))
            {
                using (Graphics graphics = Graphics.FromImage(bmp))
                {
                    graphics.TextRenderingHint = Aspose.Drawing.Text.TextRenderingHint.AntiAlias;
                    
                    //background clear
                    graphics.Clear(back);

                    //draw text
                    RectangleF rect = new RectangleF(0,0 , width, height);
                    rect.Inflate(-padding, -padding);
                    Aspose.Drawing.Brush brush = new SolidBrush(fore);
                    Aspose.Drawing.Font font = new Aspose.Drawing.Font("Arial", fontSize);
                    graphics.DrawString(text, font, brush, rect);
                }

                MemoryStream ms = new MemoryStream();
                bmp.Save(ms, Aspose.Drawing.Imaging.ImageFormat.Png);
                ms.Position = 0;

                //draw
                image.Source = ImageSource.FromStream(() => ms);
            }
        }
    }
}
