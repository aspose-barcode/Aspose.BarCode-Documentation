﻿//Copyright(c) 2001-2023 Aspose Pty Ltd.All rights reserved.

using System.Runtime.InteropServices;

namespace Aspose.Drawing.MAUI
{
    /// <summary>
    /// Aspose.Drawing Fonts Manager
    /// </summary>
    public class PrivateFontsManager
    {
        /// <summary>
        /// Register fonts from App Package in Aspose.Drawing
        /// </summary>
        ///<param name="fontFiles">list of font files added to project</param>  
        public static void RegisterFontsFromAppPackage(params string[] fontFiles)
        {
            Aspose.Drawing.Text.PrivateFontCollection collection = new Aspose.Drawing.Text.PrivateFontCollection();
            List<Stream> fonts = ReadFontsFromAppPackage(fontFiles);

            //create private fonts collection
            foreach (Stream stream in fonts)
                AddFontData(collection, stream);

            //register
            Aspose.Drawing.Text.InstalledFontCollection installed = new Aspose.Drawing.Text.InstalledFontCollection();
            installed.AddFamilies(collection.Families);
        }

        /// <summary>
        /// Reads font files added to project to streams
        /// </summary>
        ///<param name="fontFiles">list of font files added to project</param>  
        /// <returns>streams from font files added to project</returns> 
        public static List<Stream> ReadFontsFromAppPackage(params string[] fontFiles)
        {
            List < Stream > res = new List<Stream>();
            foreach(string ffile in fontFiles)
            {
                try
                {
                    if (!Microsoft.Maui.Storage.FileSystem.Current.AppPackageFileExistsAsync(ffile).Result) continue;
                    
                    List<byte> streamData = new List<byte>();
                    using (Stream fstream = Microsoft.Maui.Storage.FileSystem.Current.OpenAppPackageFileAsync(ffile).Result)
                    {
                        int realRead = 0;
                        byte[] data = new byte[262144];
                        do
                        {
                            realRead = fstream.Read(data, 0, data.Length);
                            for (int i = 0; i < realRead; ++i)
                                streamData.Add(data[i]);
                        } while (0 != realRead);
                    }
                    //add
                    res.Add(new MemoryStream(streamData.ToArray()));
                }
                catch (Exception e)
                { 
                    Console.WriteLine(e.Message);
                }
            }

            return res;
        }

        /// <summary>
        /// Adds font stream to private fonts collection
        /// </summary>
        ///<param name="privateCollection">private fonts collection where we add the following font stream</param>  
        ///<param name="fontStream">font stream</param>  
        public static void AddFontData(Aspose.Drawing.Text.PrivateFontCollection privateCollection, Stream fontStream)
        {
            byte[] fontData = new byte[fontStream.Length];
            fontStream.Position = 0;
            fontStream.Read(fontData, 0, fontData.Length);

            IntPtr dataPointer = Marshal.AllocHGlobal(fontData.Length);
            try
            {
                Marshal.Copy(fontData, 0, dataPointer, fontData.Length);
                privateCollection.AddMemoryFont(dataPointer, fontData.Length);
            }
            finally
            {
                Marshal.FreeHGlobal(dataPointer);
            }
        }
    }
}
