﻿using Aspose.Drawing;
using Aspose.Barcode.Utils;
using Aspose.BarCode.Generation;
using Aspose.BarCode.BarCodeRecognition;
using System.IO;
using System;

namespace mauibarcode;

public partial class MainBarcodePage : ContentPage
{
    public MainBarcodePage()
    {
        InitializeComponent();
        DrawImage.Source = ImageSource.FromStream(() => FileSystem.Current.OpenAppPackageFileAsync("barcode_example.png").Result);
    }

    private void OnDrawBarcodeBtn(object sender, EventArgs e)
    {
        BarcodeGenerator generator = new BarcodeGenerator(EncodeTypes.Code128, "Aspose.Barcode");
        generator.Parameters.Barcode.CodeTextParameters.Font.FamilyName = "Pristina";
        generator.Parameters.Barcode.XDimension.Pixels = 2;
        //generate and save
        MemoryStream ms = new MemoryStream();
        generator.Save(ms, BarCodeImageFormat.Png);
        ms.Position = 0;

        //draw
        DrawImage.Source = ImageSource.FromStream(() => ms);
    }

    private void OnReadBarcodeBtn(object sender, EventArgs e)
    {
        MemoryStream ms = StorageUtils.ReadAppPackageFileToMemoryStream("barcode_example.png");

        using (Bitmap bmp = new Bitmap(new MemoryStream(ms.ToArray())))
        {
            SolidBrush barcodeBrush = new SolidBrush(Aspose.Drawing.Color.FromArgb(0x6f00FF00));
            Aspose.Drawing.Font textFont = new Aspose.Drawing.Font("Pristina", 10);
            SolidBrush textBrush = new SolidBrush(Aspose.Drawing.Color.Red);

            using (Graphics graphics = Graphics.FromImage(bmp))
            {
                BarCodeReader reader = new BarCodeReader(new MemoryStream(ms.ToArray()), DecodeType.Code128, DecodeType.QR, DecodeType.DataMatrix);
                foreach (BarCodeResult result in reader.ReadBarCodes())
                {
                    graphics.FillRectangle(barcodeBrush, result.Region.Rectangle);
                    graphics.DrawString(result.CodeText, textFont, textBrush, result.Region.Rectangle.Left, result.Region.Rectangle.Top);
                }
            }

            ms = new MemoryStream();
            bmp.Save(ms, Aspose.Drawing.Imaging.ImageFormat.Png);
            ms.Position = 0;
        }

        //draw
        DrawImage.Source = ImageSource.FromStream(() => ms);
    }
}

