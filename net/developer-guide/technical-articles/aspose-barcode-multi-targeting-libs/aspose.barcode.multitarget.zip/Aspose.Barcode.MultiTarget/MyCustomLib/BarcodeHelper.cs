﻿//Copyright(c) 2001-2024 Aspose Pty Ltd.All rights reserved.
using Aspose.BarCode.Generation;
#if NETSTANDARD2_0_OR_GREATER || NETCOREAPP2_1_OR_GREATER
using Aspose.Drawing;
#else
using System.Drawing;
#endif

namespace MyCustomLib
{
    public class BarcodeHelper
    {
        public static Bitmap GenerateCode128Barcode(string CodeText)
        {
            BarcodeGenerator gen = new BarcodeGenerator(EncodeTypes.Code128, CodeText);
            gen.Parameters.Barcode.XDimension.Pixels = 2;
            return gen.GenerateBarCodeImage();
        }
    }
}
