﻿//Copyright(c) 2001-2024 Aspose Pty Ltd.All rights reserved.
using System;
using MyCustomLib;
using Aspose.BarCode.BarCodeRecognition;
#if NETSTANDARD2_0_OR_GREATER || NETCOREAPP2_1_OR_GREATER
using Aspose.Drawing;
#else
using System.Drawing;
#endif

namespace FrameworkProject
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Bitmap bmp = BarcodeHelper.GenerateCode128Barcode("Aspose.BarCode");
            using (BarCodeReader reader = new BarCodeReader(bmp))
                foreach (BarCodeResult result in reader.ReadBarCodes())
                    Console.WriteLine($"{result.CodeTypeName}:{result.CodeText}");

            Console.ReadLine();
        }
    }
}
