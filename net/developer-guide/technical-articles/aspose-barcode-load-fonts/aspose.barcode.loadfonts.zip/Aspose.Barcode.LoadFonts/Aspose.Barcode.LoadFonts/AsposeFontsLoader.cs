﻿//Copyright(c) 2001-2024 Aspose Pty Ltd.All rights reserved.
using System;
using System.IO;
using System.Runtime.InteropServices;

namespace Aspose.Barcode.LoadFonts
{
    public class AsposeFontsLoader
    {
        /// <summary>
        /// Adds font fontName to Aspose.Drawing main fonts
        /// </summary>
        ///<param name="fontName">font file</param>  
        public static void RegisterFontFromFile(string fontName)
        {
            using (Stream fontStream = new FileStream(fontName, FileMode.Open, FileAccess.Read, FileShare.Read))
                RegisterFontFromStream(fontStream);
        }

        /// <summary>
        /// Adds font stream to Aspose.Drawing main fonts
        /// </summary>
        ///<param name="fontStream">font stream</param>  
        public static void RegisterFontFromStream(Stream fontStream)
        {
            //load font
            Aspose.Drawing.Text.PrivateFontCollection collection = new Aspose.Drawing.Text.PrivateFontCollection();
            AddFontData(collection, fontStream);

            //register
            Aspose.Drawing.Text.InstalledFontCollection installed = new Aspose.Drawing.Text.InstalledFontCollection();
            installed.AddFamilies(collection.Families);
        }

        /// <summary>
        /// Adds font stream to private fonts collection
        /// </summary>
        ///<param name="privateCollection">private fonts collection where we add the following font stream</param>  
        ///<param name="fontStream">font stream</param>  
        public static void AddFontData(Aspose.Drawing.Text.PrivateFontCollection privateCollection, Stream fontStream)
        {
            byte[] fontData = new byte[fontStream.Length];
            fontStream.Position = 0;
            fontStream.Read(fontData, 0, fontData.Length);

            IntPtr dataPointer = Marshal.AllocHGlobal(fontData.Length);
            try
            {
                Marshal.Copy(fontData, 0, dataPointer, fontData.Length);
                privateCollection.AddMemoryFont(dataPointer, fontData.Length);
            }
            finally
            {
                Marshal.FreeHGlobal(dataPointer);
            }
        }
    }
}
