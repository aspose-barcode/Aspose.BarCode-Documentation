﻿//Copyright(c) 2001-2024 Aspose Pty Ltd.All rights reserved.
using System;
using Aspose.Drawing;
using Aspose.BarCode.Generation;

namespace Aspose.Barcode.LoadFonts
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //set license
            (new Aspose.BarCode.License()).SetLicense(@"..\..\..\..\license\Aspose.Total.Product.Family.lic");

            //register fonts
            AsposeFontsLoader.RegisterFontFromFile(@"..\..\..\..\fonts\ClaireAmoreth.ttf");
            
            //generate barcode
            BarcodeGenerator gen = new BarcodeGenerator(EncodeTypes.Code128, "Aspose.BarCode");
            gen.Parameters.Barcode.XDimension.Pixels = 4;
            gen.Parameters.Barcode.BarHeight.Pixels = 80;
            gen.Parameters.Barcode.CodeTextParameters.Font.Style = FontStyle.Bold;
            gen.Parameters.Barcode.CodeTextParameters.Font.FamilyName = "Claire Amoreth";
            gen.Save("code128.png", BarCodeImageFormat.Png);

            Console.ReadLine();
        }
    }
}
