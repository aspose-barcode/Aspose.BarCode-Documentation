﻿using System;
using Aspose.BarCode.Generation;
using Aspose.BarCode.BarCodeRecognition;

namespace Aspose.Barcode.NetStandard
{
    internal class Program
    {
        static void Main(string[] args)
        {
            BarcodeGenerator gen = new BarcodeGenerator(EncodeTypes.Code128, "Aspose.BarCode");
            gen.Parameters.Barcode.XDimension.Pixels = 2;
            Aspose.Drawing.Bitmap bmp = gen.GenerateBarCodeImage();

            using (BarCodeReader reader = new BarCodeReader(bmp, DecodeType.Code128))
            {
                foreach (BarCodeResult result in reader.ReadBarCodes())
                    Console.WriteLine($"{result.CodeTypeName}:{result.CodeText}");
            }
            Console.ReadLine();
        }
    }
}
